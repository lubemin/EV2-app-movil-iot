package com.example.ventiapplubjulio

data class TemperatureEntry(val temperature: Float)
